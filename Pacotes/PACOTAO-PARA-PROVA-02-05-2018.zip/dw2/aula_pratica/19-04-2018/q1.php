<?php
echo "<style>body{font-size: 28px;}</style><center>";

// $lista__compras[1] = 'Feijão';
// $lista__compras[2] = 'Arroz';
// $lista__compras[3] = 'Batata';
// $lista__compras[4] = 'Ketchup';
// for ($cont=1; $cont <=4; $cont++){
//   print $lista__compras[$cont];
//   print "<br/>";
// }

$lista__compras = array(1 => 'Feijão', 2 => 'Arroz', 3 => 'Batata', 4 => 'Ketchup');
print_r($lista__compras);
 ?>
