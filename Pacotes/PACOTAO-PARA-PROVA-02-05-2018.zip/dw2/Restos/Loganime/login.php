<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Loganime - Login</title>
  </head>
  <body>
    <form action="" method="post">
      <fieldset>
        <label>Nome de Usuário <input type="text" name="username"/></label>
        <label>Senha<input type="password" name="password"/></label>
      </fieldset>
    </form>
  </body>
</html>
