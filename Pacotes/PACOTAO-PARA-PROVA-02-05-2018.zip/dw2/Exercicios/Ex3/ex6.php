<!DOCTYPE html>
<html>
<!-- Carlos Magno  -->
  <head>
    <meta charset="utf-8">
    <title>Elevador</title>
  </head>
  <body>
    <form action="ex6s.php" method="post">
      <fieldset>
        <legend>Elevador</legend>
      <label> Peso da Pessoa 1 <input type="number" step="0.01" name="p1"></label><br>
      <label> Peso da Pessoa 2 <input type="number" step="0.01" name="p2"></label><br>
      <label> Peso da Pessoa 3 <input type="number" step="0.01" name="p3"></label><br>
      <label> Peso da Pessoa 4 <input type="number" step="0.01" name="p4"></label><br>
      <label> Peso da Pessoa 5 <input type="number" step="0.01" name="p5"></label><br>
      <input type="submit" value="Calcular"><input type="reset" value="Limpar">
    </fieldset>
    </form>
  </body>
</html>
