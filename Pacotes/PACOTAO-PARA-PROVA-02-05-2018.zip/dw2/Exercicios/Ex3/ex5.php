<!DOCTYPE html>
<html>
<!-- Carlos Magno  -->
  <head>
    <meta charset="utf-8">
    <title>Positivo ou Negativo</title>
  </head>
  <body>
    <form action="ex5s.php" method="post">
      <fieldset>
        <legend>Positivo ou Negativo</legend>
      <label> Número <input type="number" name="n"></label><br>
      <input type="submit" value="Calcular"><input type="reset" value="Limpar">
    </fieldset>
    </form>
  </body>
</html>
