<!DOCTYPE html>
<html>
<!-- Carlos Magno  -->
  <head>
    <meta charset="utf-8">
    <title>Par ou Ímpar</title>
  </head>
  <body>
    <form action="ex4s.php" method="post">
      <fieldset>
        <legend>Par ou Ímpar</legend>
      <label> Número <input type="number" name="n"></label><br>
      <input type="submit" value="Calcular"><input type="reset" value="Limpar">
    </fieldset>
    </form>
  </body>
</html>
