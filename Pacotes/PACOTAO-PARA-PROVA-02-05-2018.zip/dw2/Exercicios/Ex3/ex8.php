<!DOCTYPE html>
<html>
<!-- Carlos Magno  -->
  <head>
    <meta charset="utf-8">
    <title>Situação do Estudante</title>
  </head>
  <body>
    <form action="ex8s.php" method="post">
      <fieldset>
        <legend>Situação do Estudante</legend>
      <label> Nota 1 <input type="number" step="0.01" name="n1"></label><br>
      <label> Nota 2 <input type="number" step="0.01" name="n2"></label><br>
      <label> Nota 3 <input type="number" step="0.01" name="n3"></label><br>
      <input type="submit" value="Calcular"><input type="reset" value="Limpar">
    </fieldset>
    </form>
  </body>
</html>
