<?php
// Carlos Magno
$n = $_POST['n'];
if($n%2==0){
  echo "$n é um número par.";
}else{
  echo "$n é um número impar.";
}
 ?>
