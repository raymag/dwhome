<!DOCTYPE html>
<html>
<!-- Carlos Magno  -->
  <head>
    <meta charset="utf-8">
    <title>Assistente de Comércio</title>
  </head>
  <body>
    <form action="ex9s.php" method="post">
      <fieldset>
        <legend>Assistente de Comércio</legend>
      <label> Custo do Produto <input type="number" step="0.01" name="custo"></label><br>
      <input type="submit" value="Calcular"><input type="reset" value="Limpar">
    </fieldset>
    </form>
  </body>
</html>
