<!DOCTYPE html>
<html>
<!-- Carlos Magno  -->
  <head>
    <meta charset="utf-8">
    <title>Comerciante de Maçãs</title>
  </head>
  <body>
    <form action="ex2s.php" method="post">
      <fieldset>
        <legend>Comerciante de Maçãs</legend>
      <label>Quantidade de Maçãs: <input type="number" name="quantidade"></label><br>
      <input type="submit" value="Calcular"><input type="reset" value="Limpar">
    </fieldset>
    </form>
  </body>
</html>
