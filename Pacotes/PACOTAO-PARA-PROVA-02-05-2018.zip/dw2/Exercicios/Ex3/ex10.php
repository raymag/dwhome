<!DOCTYPE html>
<html>
<!-- Carlos Magno  -->
  <head>
    <meta charset="utf-8">
    <title>Reajuste Salarial</title>
  </head>
  <body>
    <form action="ex10s.php" method="post">
      <fieldset>
        <legend>Reajuste Salarial</legend>
      <label> Valor do Salário <input type="number" name="salario"></label><br>
      <input type="submit" value="Calcular"><input type="reset" value="Limpar">
    </fieldset>
    </form>
  </body>
</html>
