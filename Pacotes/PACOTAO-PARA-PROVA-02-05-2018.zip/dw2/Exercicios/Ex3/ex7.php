<!DOCTYPE html>
<html>
<!-- Carlos Magno  -->
  <head>
    <meta charset="utf-8">
    <title>Custo de Carro</title>
  </head>
  <body>
    <form action="ex7s.php" method="post">
      <fieldset>
        <legend>Custo de Carro</legend>
      <label> Custo de Fábrica <input type="number" name="custo_fabrica"></label><br>
      <input type="submit" value="Calcular"><input type="reset" value="Limpar">
    </fieldset>
    </form>
  </body>
</html>
