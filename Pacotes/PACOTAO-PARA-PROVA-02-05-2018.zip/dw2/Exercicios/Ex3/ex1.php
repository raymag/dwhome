<!DOCTYPE html>
<html>
<!-- Carlos Magno  -->
  <head>
    <meta charset="utf-8">
    <title>Fahrenheit para Celsius</title>
  </head>
  <body>
    <form action="ex1s.php" method="get">
      <fieldset>
        <legend>Fahrenheit para Celsius</legend>
      <label>Valor em Fahrenheit <input type="number" step="0.01" name="f"></label><br>
      <input type="submit" value="Calcular"><input type="reset" value="Limpar">
    </fieldset>
    </form>
  </body>
</html>
