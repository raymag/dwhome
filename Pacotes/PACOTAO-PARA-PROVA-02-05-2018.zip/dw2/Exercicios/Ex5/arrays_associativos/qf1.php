<!DOCTYPE html>
<html lang="pt-br">
<!-- Carlos Magno Nascimento -->
<!-- Criado em 19/04/18 -->
<head>
<meta charset="utf-8"/>
</head>
<body>
<form action="q1.php" method="POST">
<fieldset>
<label>Nome: <input type="text" name="name"/> </label><br/>
<label>Senha: <input type="password" name="passwd"/> </label><br/>
<label>E-mail: <input type="text" name="email"/> </label><br/>
<label>Idade: <input type="text" name="age"/> </label><br/>
<label>Altura: <input type="text" placeholder="Em centímetros" name="height"/> </label><br/>
<input type="submit" value="Enviar"/>
</fieldset>
</body>
</html>