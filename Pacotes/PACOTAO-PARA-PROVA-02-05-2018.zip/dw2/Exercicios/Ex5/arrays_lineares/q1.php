<?php
# ==== Carlos Magno Nascimento ==== #
# ======  Criado em 19/04/18 ====== #
echo "<style>body{background:#cdcdcd;font-size:25px;}</style><center>";
#===================================>
for($i=0;$i<30;$i++){
	$nomes[$i] = 'Magno';
}
for($j=0;$j<30;$j++){
	echo "[$j] ".$nomes[$j]."<br/>";
}

?>