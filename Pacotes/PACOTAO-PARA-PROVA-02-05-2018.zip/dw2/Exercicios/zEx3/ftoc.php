<!DOCTYPE html>
<!-- Carlos Magno Nascimento -->
<html>
  <head>
    <meta charset="utf-8">
    <title>Fahreneit para Celsius</title>
  </head>
  <body>
    <form action="ftocs.php" method="get">
      <label>Fahrenheit: <input type="number" name="f"></label><br/>
      <input type="submit" value="Converter para Celsius">
    </form>
  </body>
</html>
