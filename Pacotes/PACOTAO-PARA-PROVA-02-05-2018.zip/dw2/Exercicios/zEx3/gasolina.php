<!DOCTYPE html>
<!-- Carlos Magno -->
<html>
  <head>
    <meta charset="utf-8">
    <title>Cálculo da Gasolina</title>
  </head>
  <body>
    <form action="gasolinas.php" method="get">
      <label>Distância (KM): <input type="number" name="distancia"></label><br><br>
      <label>Preço da Gasolina: <input type="number" name="preco"></label><br>
      <input type="submit" value="Calcular">
      <input type="reset" value="Cancelar">
    </form>
  </body>
</html>
