<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Positivo ou Negativo</title>
  </head>
  <body>
    <form action="positivos.php" method="post">
      <label>Número: <input type="number" name="n"></label>
      <input type="submit"/>
    </form>
  </body>
</html>
