<?php
// Carlos Magno
$f = $_GET['f'];
echo "$f °F == ".((($f-32)*5)/9)." °C";
 ?>
