<!DOCTYPE html>
<html>
<!-- Carlos Magno -->
  <head>
    <meta charset="utf-8">
    <title>Reajuste Salarial</title>
  </head>
  <body>
    <form action="reajustes.php" method="post">
      <label>Salário: <input type="number" step="0.01" name="salario"></label><br>
      <input type="submit"/>
    </form>
  </body>
</html>
