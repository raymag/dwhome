<?php
// Carlos Magno
$n = $_POST['n'];
if($n>=0){
  echo "$n é um número positivo.";
}if($n<0){
  echo "$n é um número negativo.";
}
 ?>
