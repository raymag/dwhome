<?php
// Carlos Magno
$f = 212;
echo "$f °F == ".((($f-32)*5)/9)." °C";
 ?>
