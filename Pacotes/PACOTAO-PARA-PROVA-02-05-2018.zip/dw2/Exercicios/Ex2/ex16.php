<?php
// Carlos Magno
$salario = 1280;
if($salario<=300){
  echo "O salário reajustado é de R$ ".($salario+$salario*0.5);
}else {
  echo "O salário reajustado é de R$ ".($salario+$salario*0.3);
}
 ?>
