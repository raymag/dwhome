<?php
// Carlos Magno
$distancia = 39;
$preco = 5;
$litros = $distancia/13;
echo "Distância a ser percorrida: $distancia Km <br/>";
echo "Preço da gasolina: R$ $preco <br/>";
echo "Serão gastos $litros L de gasolina, e o total a ser pago
 será R$ ".($litros*$preco);
 ?>
