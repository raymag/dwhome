<?php
// Carlos Magno
$n = -666;
if($n>=0){
  echo "$n é um número positivo.";
}if($n<0){
  echo "$n é um número negativo.";
}
 ?>
