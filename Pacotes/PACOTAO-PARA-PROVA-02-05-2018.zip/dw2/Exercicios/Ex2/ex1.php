<?php
// Carlos Magno
$x=10;
$y=5;
$z=2;
echo "X = $x <br/> Y = $y <br/> Z = $z <br/>";
echo "O resultado de ((x-5)*y)-z resulta em: <b>".((($x-5)*$y)-$z)."</b><br/>";
 ?>
