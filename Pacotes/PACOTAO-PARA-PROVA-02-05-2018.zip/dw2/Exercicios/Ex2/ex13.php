<?php
// Carlos Magno
$n = 18;
if($n%4==0){
  echo "$n é um número divisível por 4";
}else{
  echo "$n não é um número divisível por 4";
}
 ?>
