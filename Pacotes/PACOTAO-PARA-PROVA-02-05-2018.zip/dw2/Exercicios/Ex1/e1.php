<?php
// Carlos Magno Nascimento
// 1 -----
print "1 ______________________ <br>";
print "Carlos Magno Nascimento";
print "<br/>";
// 2 -----
print "2 ______________________ <br>";
$nome = "Magno";
print $nome."<br/>";
print $nome."<br/>";
print $nome."<br/>";
print $nome."<br/>";
print $nome."<br/>";
// 3 -----
print "3 ______________________ <br>";
$num = 25682;
print $num*2;
print "<br/>";
print $num/2;
print "<br/>";
print $num+2;
print "<br/>";
print $num-2;
print "<br/>";
// 4 ------
print "4 ______________________ <br>";
$ferradura = 4;
$cavalos = 40;
print $ferradura*$cavalos;
print "<br/>";
// 5 ------
print "5 ______________________ <br>";
$nokm = 1.85;
$velocidade = 7.25;
$r = $velocidade*$nokm;
print $r;
 ?>
