echo $_SERVER["PHP_SELF"]."<br/>";
echo $_SERVER["SERVER_NAME"]."<br/>";
echo $_SERVER["DOCUMENT_ROOT"]."<br/>";
echo $_SERVER["REMOTE_ADDR"]."<br/>";
echo $_SERVER["SCRIPT_FILENAME"]."<br/>";
