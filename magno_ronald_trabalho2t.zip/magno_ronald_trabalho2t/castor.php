<?php session_start() ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="author" content="Carlos Magno / Ronald Carvaho">
    <link rel="stylesheet" href="css/style.css">
    <title>Castor</title>
</head>
<body>
    <?php include "inc/menu_logged.php"?>
    <div id="area-principal">
    <?php
    $email= $_SESSION["email"];

    include "inc/functions/conexao.php";
    $conn = conecta_mysql();

    $sql = "SELECT * FROM mensagem WHERE email = '$email' ORDER BY data_envio DESC";
    // echo $sql
    if($query = mysqli_query($conn, $sql)){
        $msgs = array();
        while($row = mysqli_fetch_array($query, MYSQLI_ASSOC)){
            $msgs[] = $row;
        }

        foreach($msgs as $msg){
            echo "<div class='bloco'>";
            echo "<p>".$msg["texto"]."</p>";
            echo "<hr/>";
            echo "<span class='data_msg'>".$msg["data_envio"].", ".$msg["id_mensagem"]."</span>";
            echo "</div>";
        }
    }
    ?>
    </div>
</body>
</html>