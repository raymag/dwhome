<div id="menu">
    <div id="menu-area">
        <h1 id="logo">Castor</h1>
        <ul id="menu-links" type="none">
            <li><a href="cadastro.php">Cadastre-se</a></li>
            <li><a href="">Sobre</a></li>
        </ul>
    </div>
</div>