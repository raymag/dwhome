<?php session_start() ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="author" content="Carlos Magno / Ronald Carvaho">
    <link rel="stylesheet" href="css/style.css">
    <title>Castor</title>
</head>
<body>
    <?php include "inc/menu_logged.php"?>
    <div id="area-principal">
    <div class="bloco">
        <form method="POST">
        <fieldset>
        <legend>Enviar Mensagem</legend>
        <label>E-mail: <input type="text" name="email_alvo" placeholder="Ex: paula@tejan.do"> </label>
        <fieldset>
            <legend>Corpo da Mensagem</legend>
            <textarea name="texto" cols="60" rows="10"></textarea>
        </fieldset>
        <input type="submit" value="Enviar">
        <input type="reset" value="Cancelar">
</fieldset>
        </form>
    </div>
    <?php
    include "inc/functions/conexao.php";
    $conn = conecta_mysql();
    if (isset($_POST['email_alvo'])){
        $email = $_POST['email_alvo'];
        $msg = $_POST['texto'];
        $sql = "INSERT INTO mensagem (email, texto) VALUES ('$email','$msg')";
        if($query = mysqli_query($conn, $sql)){
            echo "<script>alert('Mensagem Enviada Com Sucesso')</script>";
        }else{
            echo "<script>alert('Mensagem Não Enviada')</script>";
        }

    }
    ?>
    </div>
    
    </div>
</body>
</html>