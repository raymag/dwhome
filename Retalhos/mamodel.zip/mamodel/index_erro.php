<?php
$erro = $_GET["erro"];

switch($erro){
    case 1:
        header("location: index.php");  
        break;
    case 2:
        echo "<h2>Desculpe-nos, ocorreu uma falha em nosso sistema, voltaremos em breve.</h2>";
        break;
    default:
        echo "<h2>Desculpe-nos pelo transtorno, nosso sistema falhou. Estaremos resolvendo isso em breve.</h2>";
        break;
}
?>