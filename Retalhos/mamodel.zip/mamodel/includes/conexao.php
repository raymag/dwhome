<?php
	function conecta_mysql(){
		$host = "127.0.0.1";
		$user = "root";
		$passwd = "";
		$bd = "php01";
		$port = 8089;

		$conn = mysqli_connect($host, $user, $passwd, $bd, $port);
		mysqli_set_charset($conn, "utf8");

		return $conn;
	}

?>
