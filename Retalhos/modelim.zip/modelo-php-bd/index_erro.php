<?php
$erro = $_GET["erro"];

if($erro==1){
    header("location: index.php");  
}

?>