<div id="navegacao">
	<div id="area">
		<h1 id="logo"> <span class="verde">PHP</span>/<span class="verde">BD</span> </h1>
		<div id="menu">
			<a href="index.php">HOME</a>
			<a href="cadastro_usuario.php">Cadastrar Pessoa</a>
		</div>
	</div>
</div>
