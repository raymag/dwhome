<div id="navegacao">
	<div id="area">
		<h1 id="logo"> <span class="verde">PHP</span>/<span class="verde">BD</span> </h1>
		<div id="menu">
			<a href="index.php">Início</a>
			<a href="logout.php">Sair</a>
		</div>
	</div>
</div>
