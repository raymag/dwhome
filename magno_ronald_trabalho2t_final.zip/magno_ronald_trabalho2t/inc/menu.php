<div id="menu">
    <div id="menu-area">
        <h1 id="logo"><img width="30" src="img/castor.png"/> Castor</h1>
        <ul id="menu-links" type="none">
            <li><a href="index.php">Entrar</a></li>
            <li><a href="cadastro.php">Cadastre-se</a></li>
            <!-- <li><a href="">Sobre</a></li> -->
        </ul>
    </div>
</div>