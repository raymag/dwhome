<div id="menu">
    <div id="menu-area">
        <h1 id="logo"><img width="30" src="img/castor.png"/> Castor</h1>
        <ul id="menu-links" type="none">
            <li><a href="castor.php">Ver Mensagens</a></li>
            <li><a href="enviar_msg.php">Enviar Mensagem</a></li>
            <li><a href="procurar_email.php">Pesquisar Email</a></li>
            <li><a href="apagar_msg.php">Apagar Mensagem</a></li>
            <li><a href="logout.php">Sair</a></li>
            
        </ul>
    </div>
</div>